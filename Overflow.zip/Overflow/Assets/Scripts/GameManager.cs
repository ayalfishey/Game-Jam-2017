﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GameManager : MonoBehaviour {

    public GameObject platform;
    public GameObject platformRight;
    public GameObject water;
    public GameObject blockStack;
    public GameObject blockStackRight;

    public GameObject ground;

    private IEnumerator coroutine;

    // Use this for initialization
    void Start () {

        //CountDown Will Start, Waiting for it to finish to start game
        coroutine = WaitForCountDown(3);
        StartCoroutine(coroutine);

	}
    private IEnumerator WaitForCountDown(float time)
    {
        yield return new WaitForSeconds(time);
        ground.GetComponent<Ground>().StartGame();
        blockStack.GetComponent<BlockStack>().StartGame();
        blockStackRight.GetComponent<BlockStack>().StartGame();
        platform.GetComponent<Rigidbody2D>().bodyType = UnityEngine.RigidbodyType2D.Dynamic;
        platformRight.GetComponent<Rigidbody2D>().bodyType = UnityEngine.RigidbodyType2D.Dynamic;

    }

    // Update is called once per frame
    void Update () {
		
	}
}
