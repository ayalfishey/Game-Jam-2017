﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[RequireComponent(typeof(Rigidbody2D), typeof(BoxCollider2D))]
public class Block : MonoBehaviour, IPlayer
{
    #region Editor properties

    [Tooltip("Accuracy needed to place this block on top of another")]
    [Range(0f, 1f)]
    public float AccurateHitPrecentage = 0.5f;
    [Tooltip("Maximum drift when aligning the block with the wall")]
    public float MaxDrift = 0.1f;
    [Tooltip("Block speed when aligning with the wall")]
    public float DriftSpeed = 1f;

    #endregion

    #region Properties

    public int PlayerNumber { get; set; }
    public float Width
    {
        get
        {
            return this._renderer.bounds.size.x;
        }
    }
    public bool IsAttached { get; private set; }

    #endregion

    #region Private members

    private SpriteRenderer _renderer;
    private Rigidbody2D _rigidbody;

    private bool _isNeedToAlignPosition = false;
    private Drift _drift;
    private float _cameraHorizontalHalfLenght;
    private GameObject _trash;

    #endregion

    #region Public methods

    public void Drop()
    {
        if (!this._rigidbody.isKinematic)
            return;

        this.transform.rotation = new Quaternion(0, 0, 0, 0);
        this._rigidbody.isKinematic = false;
    }

    #endregion

    #region Overrides

    private void Update()
    {
        this.destroy();
    }

    private void FixedUpdate()
    {
        this.alignPosition();
    }

    private void OnCollisionEnter2D(Collision2D collision)
    {
        this.handleStacking(collision);
    }

    // Use this for initialization
    void Start()
    {
        this._trash = GameObject.Find("Trash");
        this._cameraHorizontalHalfLenght = Camera.main.orthographicSize * Screen.width / Screen.height;
        this._renderer = GetComponentInChildren<SpriteRenderer>();
        this._rigidbody = GetComponent<Rigidbody2D>();
    }

    #endregion

    #region Private methods
    private void alignPosition()
    {
        if (this._drift == null)
            return;

        if (this._isNeedToAlignPosition && this._drift.Direction != MovementDirection.None)
        {
            var newPosX = transform.position.x + (this._drift.Direction == MovementDirection.Left ? -(DriftSpeed * Time.deltaTime) : DriftSpeed * Time.deltaTime);
            this.transform.position = new Vector3(newPosX, this.transform.position.y);
        }

        if (this._drift.Direction == MovementDirection.None ||
           (this._drift.Direction == MovementDirection.Left && (this.transform.position.x <= this._drift.HorizontalPosition)) ||
           (this._drift.Direction == MovementDirection.Right && (this.transform.position.x >= this._drift.HorizontalPosition)))
        {
            this._isNeedToAlignPosition = false;
            this._drift = null;
        }
    }

    private void destroy()
    {
        var vertivalPos = transform.position.y + (this._renderer.bounds.size.y / 2);
        if (vertivalPos < -(this._cameraHorizontalHalfLenght + 1f))
        {
            DestroyObject(gameObject);
        }
    }

    private void handleStacking(Collision2D collision)
    {
        if (this._rigidbody.isKinematic)
            return;

        var stack = collision.gameObject.transform.parent == null ? null : collision.gameObject.transform.parent.GetComponent<BlockStack>();

        if (collision.gameObject.layer == 11 || stack == null || stack.PlayerNumber != PlayerNumber || collision.gameObject.layer != 8)
        {
            //TODO: Play animation and then:
            //Destroy(gameObject);

            IsAttached = true;
            this._rigidbody.isKinematic = true;
            transform.SetParent(this._trash.transform);
            return;
        }

        var bottomBlockX = collision.gameObject.transform.position.x;

        var diff = Width * AccurateHitPrecentage / 2;
        var direction = this.transform.position.x > bottomBlockX ? MovementDirection.Left : MovementDirection.Right;
        direction = this.transform.position.x == bottomBlockX ? MovementDirection.None : direction;

        IsAttached = true;

        if ((this.transform.position.x > bottomBlockX + diff) ||
            (this.transform.position.x < bottomBlockX - diff))
            this.shotMissed(this.transform.position.x > bottomBlockX + diff);
        else
            this.placeBlock(collision.gameObject.transform.parent, bottomBlockX, direction);
    }

    private void placeBlock(Transform parent, float posX, MovementDirection direction)
    {
        this._rigidbody.isKinematic = true;
        this.transform.rotation = new Quaternion(0, 0, 0, 0);
        transform.SetParent(parent);
        var drift = UnityEngine.Random.Range(-MaxDrift, MaxDrift);
        this._drift = new Drift { Direction = direction, HorizontalPosition = posX + drift };
        this._isNeedToAlignPosition = true;
    }

    //Make sure the block falls
    private void shotMissed(bool isRight)
    {
        this._rigidbody.AddForce(new Vector2(10f * (isRight ? 1 : -1), 0f));
    }

    #endregion

    #region Internal classes and enums

    public class Drift
    {
        public float HorizontalPosition { get; set; }
        public MovementDirection Direction { get; set; }
    }

    public enum MovementDirection
    {
        Left, Right, None
    }

    #endregion
}
