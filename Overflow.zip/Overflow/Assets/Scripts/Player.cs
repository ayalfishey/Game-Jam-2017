﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Player : MonoBehaviour
{

    private Platform _platform;

    // Use this for initialization
    void Start()
    {
        this._platform = this.transform.parent.GetComponentInParent<Platform>();
    }

    // Update is called once per frame
    void Update()
    {
        this.dropBlock();
    }

    private void dropBlock()
    {
        // If Space is pressed and the platform is not set to kinimatic
        if (Input.GetKeyDown(KeyCode.Space) && !this.transform.parent.GetComponentInParent<Rigidbody2D>().isKinematic)
        {
            this._platform.releaseBlock();
        }
    }
}
