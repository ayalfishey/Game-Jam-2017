﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PannelSlideOnClick : MonoBehaviour {

    public Animator pannelRight;
    public Animator pannelLeft;

    public void SlidePannels()
    {
        pannelLeft.SetBool("startPressedLeft", true);
        pannelRight.SetBool("startPressedRight", true);
    }
}
