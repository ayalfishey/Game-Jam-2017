﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class LoadSceneOnClick : MonoBehaviour {

    public Animator pannelRight;
    public Animator pannelLeft;
    public GameObject mainMenuPannel;
    public GameObject waitingPannel;

    private IEnumerator coRoutine;

    public void LoadByIndex(int sceneIndex)
    {
        coRoutine = LScene(2.0f, sceneIndex);
        StartCoroutine(coRoutine);
    }
    public void LoadByScene(Scene scene)
    {
        SceneManager.LoadScene(scene.buildIndex);
    }
    private IEnumerator LScene(float time,int index)
    {
        pannelLeft.SetBool("startPressedLeft", true);
        pannelRight.SetBool("startPressedRight", true);
        yield return new WaitForSeconds(time);
        SceneManager.LoadScene(index);
    }

    public void WaitingForPlayer()
    {
        CanvasGroup mainMenuCanvas = mainMenuPannel.GetComponent<CanvasGroup>();
        CanvasGroup waitingCanvas = waitingPannel.GetComponent<CanvasGroup>();
        mainMenuCanvas.alpha = 0;
        waitingCanvas.alpha = 1;
    }
}
