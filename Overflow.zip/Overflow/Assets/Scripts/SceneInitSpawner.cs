﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Networking;

public class SceneInitSpawner : NetworkBehaviour {

    public GameObject platformPrefab;

	// Use this for initialization
	void Start () {
        Debug.Log("SceneInitSpawner start");
        CmdSpawnObjects();

    }

    [Command]
    void CmdSpawnObjects()
    {
        GameObject platform = (GameObject)Instantiate(platformPrefab, transform.position, transform.rotation);
        NetworkServer.Spawn(platform);
    }

    // Update is called once per frame
    void Update () {
        Debug.Log("SceneInitSpawner update");

    }
}
