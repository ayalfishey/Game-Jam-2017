﻿using System;
using System.ComponentModel;

namespace UnityEngine.Networking
{
    [RequireComponent(typeof(NetworkManager))]
    [EditorBrowsable(EditorBrowsableState.Never)]
    public class NetworkLobby : MonoBehaviour
    {

        public NetworkManager manager;
        public LoadSceneOnClick loader;
        public GameObject platformPrefab;

        void Awake()
        {
            manager = GetComponent<NetworkManager>();
        }

        bool quickJoin = false;
        bool createdGame = false;
        bool joinedGame = false;
        enum States {NONE, START, PROGRESS };
        States gameState = States.NONE;
        void Update()
        {
            bool noConnection = (manager.client == null || manager.client.connection == null ||
                                 manager.client.connection.connectionId == -1);
            if (gameState == States.START)
            {
                SpawnPlayerAtStart();
            }

            if (gameState == States.PROGRESS)
            {
                return;
            }

            if (joinedGame && manager.IsClientConnected())
            {
                startGame();
            }
            if (createdGame && NetworkServer.active)
            {
                Debug.Log(NetworkServer.connections.Count);
                if (true)
                {
                    startGame();
                    return;
                }
                if (NetworkServer.connections.Count == 1)
                {
                    loader.WaitingForPlayer();
                }
                else
                {
                    if (NetworkServer.connections.Count == 2)
                    {
                        startGame();
                    }
                }
            }
            else
            {
                if (UnityEngine.Application.platform == RuntimePlatform.WebGLPlayer)
                {
                    //Cannot use WEBGL
                    return;
                }
                if (manager.matchMaker == null)
                {
                    manager.StartMatchMaker();
                }
                if (manager.matchInfo == null && manager.matches != null)
                {
                    for (int i = 0; i < manager.matches.Count; i++)
                    {
                        var match = manager.matches[i];
                        if (quickJoin && !createdGame && !joinedGame)
                        {
                            Debug.Log(match.name);
                            Debug.Log(match.currentSize);
                            if (match.currentSize == 1)
                            {
                                manager.matchMaker.JoinMatch(match.networkId, "", "", "", 0, 0, manager.OnMatchJoined);
                                joinedGame = true;
                            }
                        }
                    }
                    if (quickJoin && !createdGame && !joinedGame)
                    {
                        Debug.Log("No game found, starting a new game");
                        manager.matchMaker.CreateMatch("default", manager.matchSize, true, "", "", "", 0, 0, manager.OnMatchCreate);
                        createdGame = true;
                    }
                }
            }
        }

        private void SpawnPlayerAtStart()
        {
            gameState = States.PROGRESS;
        }

        public void joinGame()
        {
            manager.matchMaker.ListMatches(0, 20, "", false, 0, 0, manager.OnMatchList);
            quickJoin = true;
        }

        private void startGame()
        {
            Debug.Log("starting game!");
            //start game
            gameState = States.START;
            //loader.LoadByIndex(1);
            manager.ServerChangeScene("NitzanScene");
        }
    }
}