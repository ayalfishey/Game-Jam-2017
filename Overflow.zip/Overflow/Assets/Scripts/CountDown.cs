﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class CountDown : MonoBehaviour {


    private Canvas canvas;
    private UnityEngine.UI.Text countText;
    private int count;
    private float startTime;
    private float timeCount;
    private int sec;

    void Start()
    {
        countText = GetComponent<Text>();
        canvas = GetComponentInParent<Canvas>();

        startTime = Time.time;
        count = 3;
    }
    void Update()
    {
        timeCount = Time.time - startTime;
        sec = (int)(timeCount % 60f);
        if (sec >= 1)
        {
            count--;
            startTime = Time.time;
        }

        countText.text = "Game starting in: " + count;
        if (count == 0)
        {
            countText.gameObject.SetActive(false);
        }
    }
}
