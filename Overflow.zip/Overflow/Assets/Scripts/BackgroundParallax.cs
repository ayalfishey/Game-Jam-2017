﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BackgroundParallax : MonoBehaviour
{
    public bool IsScrolling = true;

    private float _cameraVerticalHalfLenght;

    // Use this for initialization
    void Start()
    {
        this._cameraVerticalHalfLenght = Camera.main.orthographicSize;
    }

    // Update is called once per frame
    void FixedUpdate()
    {
        this.animateBackground();
    }

    private void animateBackground()
    {
        if (!IsScrolling)
            return;

        foreach (Transform child in transform)
        {
            var layer = child.GetComponent<BackgroundLayer>();

            if (layer == null)
                continue;
            
            var childHalfHeigth = layer.HalfHeigth;
            child.position = child.position + Vector3.down * Time.deltaTime * layer.Speed;
            var verticalPos = child.position.y + childHalfHeigth;
            //print(rightPos);
            if ((this._cameraVerticalHalfLenght - 1f) > verticalPos && !layer.IsCloned)
            {
                Instantiate(child, new Vector3(child.position.x, verticalPos + childHalfHeigth, child.position.z), child.rotation, transform);
                layer.IsCloned = true;
            }
        }
    }
}
