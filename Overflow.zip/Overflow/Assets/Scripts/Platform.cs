﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Platform : MonoBehaviour
{
    public GameObject block;
    public GameObject spawnpoint;
    private Block currentBlock;
    private bool isReleased = false;
    // Use this for initialization
    void Start () {
        
    }
	
	// Update is called once per frame
	void Update () {
        if (currentBlock == null)
        {
            CmdSpawnBlock();
        } 
        else
        {
            if (isReleased && currentBlock.IsAttached)
            {
                CmdSpawnBlock();
            }
        }
    }
   
    public void CmdSpawnBlock()
    {
        GameObject tempBlock = Instantiate(block, spawnpoint.transform.position, spawnpoint.transform.rotation);
        currentBlock = tempBlock.GetComponent<Block> ();
        currentBlock.transform.parent = spawnpoint.transform;
        isReleased = false;
        // Spawn the block on the Clients
        //Network.Spawn(block);
    }

    public void releaseBlock()
    {
        currentBlock.Drop();
        isReleased = true;
    }
}
