﻿
using UnityEngine;
using System.Collections;

// @NOTE the attached sprite's position should be "top left" or the children will not align properly
// Strech out the image as you need in the sprite render, the following script will auto-correct it when rendered in the game
[RequireComponent(typeof(SpriteRenderer))]

// Generates a nice set of repeated sprites inside a streched sprite renderer
// @NOTE Vertical only, you can easily expand this to horizontal with a little tweaking
public class Ground : MonoBehaviour
{
    public float Speed = 5f;

    SpriteRenderer _renderer;
    private Rigidbody2D _rigidbody;
    private float _cameraHorizontalHalfLenght;

    void Awake()
    {
        this.drawTiles();
    }

    private void Start()
    {
        this._rigidbody = GetComponent<Rigidbody2D>();
        this._cameraHorizontalHalfLenght = Camera.main.orthographicSize * Screen.width / Screen.height;
    }

    private void drawTiles()
    {
        // Get the current sprite with an unscaled size
        _renderer = GetComponent<SpriteRenderer>();
        Vector2 spriteSize = new Vector2(_renderer.bounds.size.x / transform.localScale.x, _renderer.bounds.size.y / transform.localScale.y);

        // Generate a child prefab of the sprite renderer
        
        GameObject childPrefab = new GameObject();
        SpriteRenderer childSprite = childPrefab.AddComponent<SpriteRenderer>();
        childPrefab.transform.position = transform.position;
        childSprite.sprite = _renderer.sprite;

        // Loop through and spit out repeated tiles
        GameObject child;
        for (int i = 1, l = (int)Mathf.Round(_renderer.bounds.size.x); i < l; i++)
        {
            child = Instantiate(childPrefab) as GameObject;
            child.transform.position = transform.position - (new Vector3(spriteSize.x, 0, 0) * i);
            child.transform.parent = transform;
        }

        // Set the parent last on the prefab to prevent transform displacement
        childPrefab.transform.parent = transform;

        // Disable the currently existing sprite component since its now a repeated image
        _renderer.enabled = false;
    }


    private void destroy()
    {
        var vertivalPos = transform.position.y;
        if (vertivalPos < -(this._cameraHorizontalHalfLenght + 1f))
        {
            DestroyObject(gameObject);
        }
    }

    public void StartGame()
    {
        this._rigidbody.velocity = Vector2.down * Speed * Time.deltaTime;
    }
}