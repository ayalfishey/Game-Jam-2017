﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BackgroundLayer : MonoBehaviour
{
    public float Speed;

    [HideInInspector]
    public bool IsCloned = false;
    public float HalfHeigth
    {
        get
        {
            return Camera.main.orthographicSize * 1.5f;
        }
    }

    private float _cameraVerticallHalfLenght;

    // Use this for initialization
    void Start()
    {
        this._cameraVerticallHalfLenght = Camera.main.orthographicSize;
    }

    // Update is called once per frame
    void Update()
    {
        var verticalPos = transform.position.y + HalfHeigth;
        if (verticalPos < (this._cameraVerticallHalfLenght + 1f) * -1)
            Destroy(gameObject);
    }
}
