﻿using UnityEngine;
using System.Collections;

public class LineRendererCode : MonoBehaviour {

	//Line Renderer
	public LineRenderer myLineRenderer;
	public Transform myPoint1;
	public Transform myPoint2;

	//Material
	public Material myMaterial;
	public Texture myTexture;
	public Sprite mySprite;
	public float xScaleFactor;
	public float adjustedYSize;
	private float adjustedXSize;
	public static Texture2D textureFromSprite(Sprite sprite)
	{
		if(sprite.rect.width != sprite.texture.width){
			Texture2D newText = new Texture2D((int)sprite.rect.width,(int)sprite.rect.height);
			Color[] newColors = sprite.texture.GetPixels((int)sprite.textureRect.x, 
				(int)sprite.textureRect.y, 
				(int)sprite.textureRect.width, 
				(int)sprite.textureRect.height );
			newText.SetPixels(newColors);
			newText.Apply();
			return newText;
		} else
			return sprite.texture;
	}
	void Start() {
		//myTexture = textureFromSprite (mySprite);
	}
	// Update is called once per frame
	void Update () {
		//myMaterial.SetTexture(0, myTexture);

		myLineRenderer.SetPosition(0,myPoint1.position);
		myLineRenderer.SetPosition(1,myPoint2.position);

		adjustedXSize = xScaleFactor * (Mathf.Abs(Vector2.Distance(myPoint1.position,myPoint2.position)));

		myMaterial.mainTextureScale = new Vector2(adjustedXSize, adjustedYSize);
	}
}
