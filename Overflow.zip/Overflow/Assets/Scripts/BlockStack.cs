﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BlockStack : MonoBehaviour, IPlayer
{
    public float Speed = 5f;


    public int PlayerNumber { get; set; }


    private Rigidbody2D _rigidbody;


    // Use this for initialization
    void Start()
    {
        this._rigidbody = GetComponent<Rigidbody2D>();
    }

    public void StartGame()
    {
        this._rigidbody.velocity = Vector2.down * Speed * Time.deltaTime;
    }
}
